import React from 'react'
export default function Footer(){
  return (
    <footer className="bg-[#071029] text-gray-200 mt-12">
      <div className="container mx-auto px-4 py-8 grid grid-cols-1 md:grid-cols-3 gap-6">
        <div>
          <img src="/src/assets/logo.png" alt="logo" className="w-16 h-16 mb-2"/>
          <p className="text-sm">أمجاد وطن — تحويل الفكرة إلى تجربة. تواصل معنا: hello@amjadwatan.sa</p>
        </div>
        <div>
          <h4 className="font-semibold mb-2">روابط سريعة</h4>
          <ul className="text-sm space-y-1">
            <li>الرئيسية</li>
            <li>الخدمات</li>
            <li>المشاريع</li>
          </ul>
        </div>
        <div>
          <h4 className="font-semibold mb-2">تابعنا</h4>
          <p className="text-sm">إنستغرام • لينكدإن • تيك توك</p>
        </div>
      </div>
      <div className="text-center py-4 text-xs bg-black/20">© {new Date().getFullYear()} أمجاد وطن. كل الحقوق محفوظة.</div>
    </footer>
  )
}