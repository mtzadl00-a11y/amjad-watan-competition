import React from 'react'
export default function Header({onNavigate}){
  return (
    <header className="bg-gradient-to-r from-[var(--primary)]/90 to-[var(--accent)]/80 text-white">
      <div className="container mx-auto px-4 py-4 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <img src="/src/assets/logo.png" alt="logo" className="w-14 h-14 rounded-md shadow-md" />
          <div>
            <div className="text-xl font-bold">أمجاد وطن</div>
            <div className="text-sm opacity-90">تنظيم الفعاليات - تصميم البوثات - هدايا الشركات</div>
          </div>
        </div>
        <nav className="flex items-center gap-4">
          <button onClick={()=>onNavigate && onNavigate('landing')} className="px-3 py-2 rounded-md hover:bg-white/10">الرئيسية</button>
          <button onClick={()=>onNavigate && onNavigate('register')} className="px-3 py-2 rounded-md hover:bg-white/10">التسجيل</button>
          <button onClick={()=>onNavigate && onNavigate('admin')} className="px-3 py-2 rounded-md bg-white/10">لوحة التحكم</button>
        </nav>
      </div>
    </header>
  )
}