import React from 'react'
export default function Landing({onRegister}){
  return (
    <section className="py-12">
      <div className="container mx-auto px-4 grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
        <div>
          <h1 className="text-4xl md:text-5xl font-extrabold text-[var(--accent)]">أمجاد وطن</h1>
          <p className="mt-4 text-lg text-gray-200 max-w-xl">نحو فعاليات تتذكّرها الشركات والجمهور. تنظيم معارض، تصميم بوات، هدايا شركاتية، وحلول تسويقية مبتكرة.</p>
          <div className="mt-6 flex gap-3">
            <button onClick={onRegister} className="px-6 py-3 rounded-full bg-[var(--accent)] text-black font-bold">سجل الآن</button>
            <a className="px-6 py-3 rounded-full border border-white/20">المزيد</a>
          </div>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <img src="/src/assets/hero1.jpg" className="w-full rounded-xl shadow-lg" alt="hero1"/>
          <img src="/src/assets/hero2.jpg" className="w-full rounded-xl shadow-lg" alt="hero2"/>
        </div>
      </div>
    </section>
  )
}